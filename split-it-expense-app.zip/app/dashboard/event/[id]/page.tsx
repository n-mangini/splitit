'use client'

import { useState, use } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Spinner } from '@/components/ui/spinner'
import { 
  ArrowLeft, 
  Plus, 
  Users, 
  Receipt, 
  Share2,
  MoreVertical,
  Edit,
  Trash2,
  Copy,
  Check,
  Calculator,
  History,
  UserPlus
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { 
  mockEvents, 
  formatCurrency, 
  formatDate, 
  categoryInfo, 
  getInitials,
  getInviteLink,
  calculateBalances,
  calculateSettlements
} from '@/lib/mock-data'
import { ExpenseCategory } from '@/lib/types'

export default function EventDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = use(params)
  const router = useRouter()
  const event = mockEvents.find(e => e.id === resolvedParams.id) || mockEvents[0]
  
  const [activeTab, setActiveTab] = useState('expenses')
  const [showAddExpense, setShowAddExpense] = useState(false)
  const [showAddParticipant, setShowAddParticipant] = useState(false)
  const [showShareDialog, setShowShareDialog] = useState(false)
  const [copied, setCopied] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Add expense form state
  const [expenseName, setExpenseName] = useState('')
  const [expenseAmount, setExpenseAmount] = useState('')
  const [expensePaidBy, setExpensePaidBy] = useState('')
  const [expenseCategory, setExpenseCategory] = useState<ExpenseCategory>('other')
  const [expenseSplitBetween, setExpenseSplitBetween] = useState<string[]>([])

  // Add participant form state
  const [newParticipantName, setNewParticipantName] = useState('')

  const balances = calculateBalances(event)
  const settlements = calculateSettlements(balances)
  const totalExpenses = event.expenses.reduce((acc, exp) => acc + exp.amount, 0)

  const handleCopyLink = () => {
    navigator.clipboard.writeText(getInviteLink(event.inviteCode))
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 500))
    setIsLoading(false)
    setShowAddExpense(false)
    // Reset form
    setExpenseName('')
    setExpenseAmount('')
    setExpensePaidBy('')
    setExpenseCategory('other')
    setExpenseSplitBetween([])
  }

  const handleAddParticipant = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 500))
    setIsLoading(false)
    setShowAddParticipant(false)
    setNewParticipantName('')
  }

  const toggleParticipantSplit = (participantId: string) => {
    if (expenseSplitBetween.includes(participantId)) {
      setExpenseSplitBetween(expenseSplitBetween.filter(id => id !== participantId))
    } else {
      setExpenseSplitBetween([...expenseSplitBetween, participantId])
    }
  }

  const selectAllParticipants = () => {
    setExpenseSplitBetween(event.participants.map(p => p.id))
  }

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-6">
        <Link 
          href="/dashboard" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-4"
        >
          <ArrowLeft className="h-4 w-4" />
          <span className="text-sm">Volver</span>
        </Link>
        
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-2xl font-bold text-primary">
                {event.name.charAt(0)}
              </span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">{event.name}</h1>
              {event.description && (
                <p className="text-muted-foreground text-sm mt-1">{event.description}</p>
              )}
              <div className="flex items-center gap-3 mt-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {event.participants.length} participantes
                </span>
                <span className="flex items-center gap-1">
                  <Receipt className="h-4 w-4" />
                  {event.expenses.length} gastos
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Share2 className="h-4 w-4" />
                  <span className="hidden sm:inline">Compartir</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Compartir evento</DialogTitle>
                  <DialogDescription>
                    Comparte este link para que otros puedan unirse al evento
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="flex gap-2">
                    <Input 
                      readOnly 
                      value={getInviteLink(event.inviteCode)}
                      className="bg-muted"
                    />
                    <Button onClick={handleCopyLink} className="gap-2">
                      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      {copied ? 'Copiado!' : 'Copiar'}
                    </Button>
                  </div>
                  <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                    <p className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">Codigo de invitacion:</span>{' '}
                      {event.inviteCode}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Los invitados pueden acceder sin crear una cuenta
                    </p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-3 text-center">
            <p className="text-xs text-muted-foreground">Total</p>
            <p className="text-lg font-bold text-foreground">{formatCurrency(totalExpenses)}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-3 text-center">
            <p className="text-xs text-muted-foreground">Por persona</p>
            <p className="text-lg font-bold text-foreground">
              {formatCurrency(totalExpenses / event.participants.length)}
            </p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-3 text-center">
            <p className="text-xs text-muted-foreground">Pendientes</p>
            <p className="text-lg font-bold text-foreground">{settlements.filter(s => !s.settled).length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-flex">
          <TabsTrigger value="expenses" className="gap-2">
            <Receipt className="h-4 w-4 hidden sm:block" />
            Gastos
          </TabsTrigger>
          <TabsTrigger value="participants" className="gap-2">
            <Users className="h-4 w-4 hidden sm:block" />
            Personas
          </TabsTrigger>
          <TabsTrigger value="balances" className="gap-2">
            <Calculator className="h-4 w-4 hidden sm:block" />
            Balances
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <History className="h-4 w-4 hidden sm:block" />
            Historial
          </TabsTrigger>
        </TabsList>

        {/* Expenses Tab */}
        <TabsContent value="expenses" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={showAddExpense} onOpenChange={setShowAddExpense}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Agregar gasto
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Nuevo gasto</DialogTitle>
                  <DialogDescription>
                    Registra un nuevo gasto para dividir
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddExpense} className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="expense-name">Descripcion *</Label>
                    <Input
                      id="expense-name"
                      placeholder="Ej: Cena, Hotel, Taxi..."
                      value={expenseName}
                      onChange={(e) => setExpenseName(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="expense-amount">Monto *</Label>
                    <Input
                      id="expense-amount"
                      type="number"
                      placeholder="0"
                      value={expenseAmount}
                      onChange={(e) => setExpenseAmount(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="expense-paid-by">Pagado por *</Label>
                    <Select value={expensePaidBy} onValueChange={setExpensePaidBy}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona quien pago" />
                      </SelectTrigger>
                      <SelectContent>
                        {event.participants.map((p) => (
                          <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="expense-category">Categoria</Label>
                    <Select value={expenseCategory} onValueChange={(v) => setExpenseCategory(v as ExpenseCategory)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(categoryInfo).map(([key, info]) => (
                          <SelectItem key={key} value={key}>{info.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Dividir entre *</Label>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm"
                        onClick={selectAllParticipants}
                      >
                        Seleccionar todos
                      </Button>
                    </div>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {event.participants.map((p) => (
                        <div key={p.id} className="flex items-center gap-2">
                          <Checkbox
                            id={`split-${p.id}`}
                            checked={expenseSplitBetween.includes(p.id)}
                            onCheckedChange={() => toggleParticipantSplit(p.id)}
                          />
                          <label htmlFor={`split-${p.id}`} className="text-sm">{p.name}</label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" className="flex-1" onClick={() => setShowAddExpense(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" className="flex-1" disabled={isLoading}>
                      {isLoading ? <Spinner className="h-4 w-4" /> : 'Guardar'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {event.expenses.length === 0 ? (
            <Card className="bg-card border-border border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="h-14 w-14 rounded-full bg-muted flex items-center justify-center mb-4">
                  <Receipt className="h-7 w-7 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Sin gastos todavia</h3>
                <p className="text-sm text-muted-foreground text-center mb-4">
                  Agrega el primer gasto para empezar a dividir
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {event.expenses.map((expense) => {
                const payer = event.participants.find(p => p.id === expense.paidBy)
                const category = expense.category ? categoryInfo[expense.category] : null

                return (
                  <Card key={expense.id} className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className={`h-10 w-10 rounded-lg flex items-center justify-center flex-shrink-0 ${category?.color || 'bg-muted'}/20`}>
                          <Receipt className={`h-5 w-5 ${category?.color?.replace('bg-', 'text-') || 'text-muted-foreground'}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium text-foreground truncate">{expense.name}</h4>
                            {category && (
                              <Badge variant="secondary" className="text-xs">
                                {category.label}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {payer?.name} pago - {formatDate(expense.date)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-foreground">{formatCurrency(expense.amount)}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatCurrency(expense.amount / expense.splitBetween.length)} c/u
                          </p>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="h-4 w-4 mr-2" />
                              Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* Participants Tab */}
        <TabsContent value="participants" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={showAddParticipant} onOpenChange={setShowAddParticipant}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <UserPlus className="h-4 w-4" />
                  Agregar persona
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Agregar participante</DialogTitle>
                  <DialogDescription>
                    Agrega una nueva persona al evento
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddParticipant} className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="participant-name">Nombre *</Label>
                    <Input
                      id="participant-name"
                      placeholder="Nombre del participante"
                      value={newParticipantName}
                      onChange={(e) => setNewParticipantName(e.target.value)}
                    />
                  </div>
                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" className="flex-1" onClick={() => setShowAddParticipant(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" className="flex-1" disabled={isLoading}>
                      {isLoading ? <Spinner className="h-4 w-4" /> : 'Agregar'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-2">
            {event.participants.map((participant) => {
              const balance = balances.find(b => b.participantId === participant.id)
              
              return (
                <Card key={participant.id} className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-medium text-primary">
                          {getInitials(participant.name)}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium text-foreground truncate">{participant.name}</h4>
                          {participant.isGuest && (
                            <Badge variant="secondary" className="text-xs">Invitado</Badge>
                          )}
                        </div>
                        {participant.email && (
                          <p className="text-sm text-muted-foreground truncate">{participant.email}</p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Pago</p>
                        <p className="font-medium text-foreground">{formatCurrency(balance?.totalPaid || 0)}</p>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        {/* Balances Tab */}
        <TabsContent value="balances" className="space-y-6">
          {/* Balance Summary */}
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Resumen de balances</h3>
            <div className="space-y-2">
              {balances.map((balance) => (
                <Card key={balance.participantId} className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-medium text-primary">
                          {getInitials(balance.participantName)}
                        </span>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-foreground">{balance.participantName}</h4>
                        <p className="text-sm text-muted-foreground">
                          Pago {formatCurrency(balance.totalPaid)} - Debe {formatCurrency(balance.totalOwed)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold ${balance.netBalance >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                          {balance.netBalance >= 0 ? '+' : ''}{formatCurrency(balance.netBalance)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {balance.netBalance > 0 ? 'A favor' : balance.netBalance < 0 ? 'En contra' : 'Saldado'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Settlements */}
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Pagos sugeridos</h3>
            {settlements.length === 0 ? (
              <Card className="bg-card border-border">
                <CardContent className="py-8 text-center">
                  <Check className="h-10 w-10 text-green-500 mx-auto mb-3" />
                  <p className="text-foreground font-medium">Todo saldado!</p>
                  <p className="text-sm text-muted-foreground">No hay pagos pendientes</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-2">
                {settlements.map((settlement, index) => (
                  <Card key={index} className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-red-500/20 flex items-center justify-center flex-shrink-0">
                          <span className="text-sm font-medium text-red-500">
                            {getInitials(settlement.fromName)}
                          </span>
                        </div>
                        <div className="flex-1 text-center">
                          <p className="text-sm text-muted-foreground">debe pagar</p>
                          <p className="font-bold text-foreground">{formatCurrency(settlement.amount)}</p>
                          <p className="text-sm text-muted-foreground">a</p>
                        </div>
                        <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                          <span className="text-sm font-medium text-green-500">
                            {getInitials(settlement.toName)}
                          </span>
                        </div>
                        <Button size="sm" variant="outline">
                          Marcar pagado
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-4">
          <Card className="bg-card border-border">
            <CardContent className="py-8 text-center">
              <History className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-foreground font-medium">Historial de actividad</p>
              <p className="text-sm text-muted-foreground">Proximamente: ver todos los movimientos del evento</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
