'use client'

import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Plus, 
  Users, 
  Receipt, 
  ChevronRight,
  Calendar,
  TrendingUp,
  TrendingDown
} from 'lucide-react'
import { mockEvents, formatCurrency, formatRelativeDate, calculateBalances } from '@/lib/mock-data'

export default function DashboardPage() {
  const totalOwed = mockEvents.reduce((acc, event) => {
    const balances = calculateBalances(event)
    const userBalance = balances.find(b => b.participantId === 'p-1')
    return acc + (userBalance?.netBalance || 0)
  }, 0)

  return (
    <div className="p-4 lg:p-8">
      <div className="mb-8">
        <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Hola, Juan</h1>
        <p className="text-muted-foreground mt-1">Gestiona tus gastos compartidos</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Eventos activos</p>
                <p className="text-2xl font-bold text-foreground mt-1">{mockEvents.length}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Participantes</p>
                <p className="text-2xl font-bold text-foreground mt-1">
                  {mockEvents.reduce((acc, e) => acc + e.participants.length, 0)}
                </p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-secondary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Tu balance</p>
                <p className={`text-2xl font-bold mt-1 ${totalOwed >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {totalOwed >= 0 ? '+' : ''}{formatCurrency(totalOwed)}
                </p>
              </div>
              <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${totalOwed >= 0 ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                {totalOwed >= 0 ? (
                  <TrendingUp className="h-5 w-5 text-green-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground">Total gastos</p>
                <p className="text-2xl font-bold text-foreground mt-1">
                  {formatCurrency(mockEvents.reduce((acc, e) => acc + e.expenses.reduce((a, exp) => a + exp.amount, 0), 0))}
                </p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Receipt className="h-5 w-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">Mis eventos</h2>
        <Link href="/dashboard/new">
          <Button size="sm" className="gap-2">
            <Plus className="h-4 w-4" />
            <span className="hidden sm:inline">Nuevo evento</span>
          </Button>
        </Link>
      </div>

      <div className="space-y-3">
        {mockEvents.map((event) => {
          const totalExpenses = event.expenses.reduce((acc, exp) => acc + exp.amount, 0)
          const balances = calculateBalances(event)
          const userBalance = balances.find(b => b.participantId === 'p-1')

          return (
            <Link key={event.id} href={`/dashboard/event/${event.id}`}>
              <Card className="bg-card border-border hover:border-primary/50 transition-colors cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-lg font-bold text-primary">
                        {event.name.charAt(0)}
                      </span>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-foreground truncate">{event.name}</h3>
                        {event.expenses.length === 0 && (
                          <Badge variant="secondary" className="text-xs">Sin gastos</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Users className="h-3.5 w-3.5" />
                          {event.participants.length}
                        </span>
                        <span className="flex items-center gap-1">
                          <Receipt className="h-3.5 w-3.5" />
                          {event.expenses.length}
                        </span>
                        <span className="hidden sm:inline">
                          {formatRelativeDate(event.createdAt)}
                        </span>
                      </div>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <p className="text-sm text-muted-foreground">Total</p>
                      <p className="font-semibold text-foreground">{formatCurrency(totalExpenses)}</p>
                      {userBalance && userBalance.netBalance !== 0 && (
                        <p className={`text-xs mt-1 ${userBalance.netBalance > 0 ? 'text-green-500' : 'text-red-500'}`}>
                          {userBalance.netBalance > 0 ? 'Te deben ' : 'Debes '}
                          {formatCurrency(Math.abs(userBalance.netBalance))}
                        </p>
                      )}
                    </div>

                    <ChevronRight className="h-5 w-5 text-muted-foreground hidden sm:block" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>

      {mockEvents.length === 0 && (
        <Card className="bg-card border-border border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Receipt className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">Sin eventos todavia</h3>
            <p className="text-sm text-muted-foreground text-center mb-4 max-w-xs">
              Crea tu primer evento para empezar a dividir gastos con amigos
            </p>
            <Link href="/dashboard/new">
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Crear evento
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
