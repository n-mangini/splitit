'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Users, 
  Receipt, 
  Calculator, 
  Share2, 
  ArrowRight,
  CheckCircle2,
  Smartphone,
  Globe
} from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-lg">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
                <span className="text-lg font-bold text-primary-foreground">S</span>
              </div>
              <span className="text-xl font-bold text-foreground">SplitIt</span>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Funciones
              </a>
              <a href="#how-it-works" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Como funciona
              </a>
            </nav>
            <div className="flex items-center gap-3">
              <Link href="/login">
                <Button variant="ghost" size="sm">Iniciar sesion</Button>
              </Link>
              <Link href="/register">
                <Button size="sm">Crear cuenta</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            <div className="flex-1 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 mb-6">
                <span className="text-sm font-medium text-primary">Nuevo</span>
                <span className="text-sm text-muted-foreground">Pagos optimizados con IA</span>
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
                Divide gastos
                <span className="text-primary"> sin complicaciones</span>
              </h1>
              <p className="mt-6 text-lg text-muted-foreground max-w-xl mx-auto lg:mx-0 text-pretty">
                La forma mas simple de dividir gastos entre amigos, viajes, juntadas y eventos. 
                Sin peleas, sin confusiones, solo cuentas claras.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link href="/register">
                  <Button size="lg" className="w-full sm:w-auto gap-2">
                    Empezar gratis
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/join/demo">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto">
                    Ver demo
                  </Button>
                </Link>
              </div>
              <div className="mt-8 flex items-center gap-6 justify-center lg:justify-start text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span>Sin tarjeta</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span>100% gratis</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span>Sin registro para invitados</span>
                </div>
              </div>
            </div>
            
            {/* Hero Phone Mockup */}
            <div className="flex-1 w-full max-w-md">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 blur-3xl rounded-full" />
                <Card className="relative bg-card border-border shadow-2xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <p className="text-sm text-muted-foreground">Balance total</p>
                        <p className="text-3xl font-bold text-foreground">$100,000</p>
                      </div>
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <Calculator className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-sm font-medium">JP</div>
                          <div>
                            <p className="font-medium text-foreground">Juan Perez</p>
                            <p className="text-xs text-muted-foreground">Pago hotel</p>
                          </div>
                        </div>
                        <span className="text-sm font-medium text-primary">+$45,000</span>
                      </div>
                      <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-secondary/20 flex items-center justify-center text-sm font-medium">MG</div>
                          <div>
                            <p className="font-medium text-foreground">Maria Garcia</p>
                            <p className="text-xs text-muted-foreground">Cena grupal</p>
                          </div>
                        </div>
                        <span className="text-sm font-medium text-secondary">+$12,500</span>
                      </div>
                      <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center text-sm font-medium">CL</div>
                          <div>
                            <p className="font-medium text-foreground">Carlos Lopez</p>
                            <p className="text-xs text-muted-foreground">Alquiler auto</p>
                          </div>
                        </div>
                        <span className="text-sm font-medium text-blue-400">+$28,000</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
              Todo lo que necesitas para dividir gastos
            </h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
              Funciones pensadas para hacer tu vida mas facil
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardContent className="p-6">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Grupos ilimitados</h3>
                <p className="text-sm text-muted-foreground">
                  Crea eventos para viajes, juntadas, departamentos o cualquier gasto compartido.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardContent className="p-6">
                <div className="h-12 w-12 rounded-lg bg-secondary/10 flex items-center justify-center mb-4">
                  <Receipt className="h-6 w-6 text-secondary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Gastos detallados</h3>
                <p className="text-sm text-muted-foreground">
                  Registra quien pago, entre quienes se divide y categoriza cada gasto.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardContent className="p-6">
                <div className="h-12 w-12 rounded-lg bg-blue-500/10 flex items-center justify-center mb-4">
                  <Calculator className="h-6 w-6 text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Calculo automatico</h3>
                <p className="text-sm text-muted-foreground">
                  Balances en tiempo real y sugerencias de pagos optimizados.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardContent className="p-6">
                <div className="h-12 w-12 rounded-lg bg-pink-500/10 flex items-center justify-center mb-4">
                  <Share2 className="h-6 w-6 text-pink-400" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">Invita sin registro</h3>
                <p className="text-sm text-muted-foreground">
                  Comparte un link y tus amigos pueden ver y agregar gastos sin crear cuenta.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
              Tan simple como 1, 2, 3
            </h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Divide gastos en minutos, no en horas
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            <div className="text-center">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary text-primary-foreground text-2xl font-bold mb-6">
                1
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Crea un evento</h3>
              <p className="text-muted-foreground">
                Dale un nombre a tu grupo de gastos: viaje, juntada, depto, lo que sea.
              </p>
            </div>
            
            <div className="text-center">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-secondary text-secondary-foreground text-2xl font-bold mb-6">
                2
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Agrega gastos</h3>
              <p className="text-muted-foreground">
                Cada vez que alguien paga, lo registra. Indicando monto y entre quienes se divide.
              </p>
            </div>
            
            <div className="text-center">
              <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-blue-500 text-white text-2xl font-bold mb-6">
                3
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Listo, a saldar</h3>
              <p className="text-muted-foreground">
                SplitIt calcula quien le debe a quien y sugiere la forma mas eficiente de saldar.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mobile CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="mx-auto max-w-4xl text-center">
          <div className="flex justify-center gap-4 mb-8">
            <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center">
              <Smartphone className="h-7 w-7 text-primary" />
            </div>
            <div className="h-14 w-14 rounded-xl bg-secondary/10 flex items-center justify-center">
              <Globe className="h-7 w-7 text-secondary" />
            </div>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Funciona en todos tus dispositivos
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Accede desde tu celular, tablet o computadora. Tus gastos siempre sincronizados.
          </p>
          <Link href="/register">
            <Button size="lg" className="gap-2">
              Crear mi primer evento
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <span className="text-sm font-bold text-primary-foreground">S</span>
              </div>
              <span className="text-lg font-bold text-foreground">SplitIt</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Hecho con cuidado por el equipo Kiwii
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Terminos
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Privacidad
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Contacto
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
